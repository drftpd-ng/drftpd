----------------------------
JPF - Java Plug-in Framework
----------------------------

Welcome to JPF!

JPF is a general-purpose plug-in framework intended to help building scalable,
extendable Java applications with low cost of maintenance. The framework is
specially designed to be easily included into Java project of any kind.

For more information see project documentation in docs folder or visit JPF
website at http://jpf.sourceforge.net
/*
 * libreplacer, Java library to support C-sprintf alike text formatting
 * Copyright (C) 2002 Tanesha FTPD Project, www.tanesha.net
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
/*
 * $Id: Percent.java,v 1.4 2002/12/12 13:06:48 flower Exp $
 */
package org.tanesha.replacer.formatters;

// project imports
import org.tanesha.replacer.ReplacerFormat;

/**
 * Stringformatter helper to format percents.
 * <p>
 * It can be used to create output like;
 * <code><pre>######----</pre></code>
 *
 * @author Soren, www.tanesha.net
 */
public class Percent implements StringFormatter {

    private float _per;
    private char _a, _b;

    /**
     * Creates a new percent formatter.
     *
     * @param per the percent value, eg, 0.20 = 20%
     * @param a the active char, used for the active part of the percent bar, eg. '#'
     * @param b the inactive char, used for the inactive part of the percent bar, eg '-'
     */
    public Percent(float per, char a, char b) {
        _per = per;
        _a = a;
        _b = b;
    }

    // Implements StringFormatter
    public String format(boolean align, int p, int q) {

        if (p == ReplacerFormat.UNDEF)
            return "<no width specified>";

        int gw = Math.round(_per * p);

        StringBuffer o = new StringBuffer();

        for (int i = 0; i < gw; i++)
            o.append(_a);
        for (int i = gw; i < p; i++)
            o.append(_b);

        return o.toString();
    }

}

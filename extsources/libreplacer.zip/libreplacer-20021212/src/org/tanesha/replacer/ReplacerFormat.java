/*
 * libreplacer, Java library to support C-sprintf alike text formatting
 * Copyright (C) 2002 Tanesha FTPD Project, www.tanesha.net
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
/*
 * $Id: ReplacerFormat.java,v 1.8 2002/12/12 13:06:48 flower Exp $
 */
package org.tanesha.replacer;

import org.tanesha.replacer.formatters.StringFormatter;
import java.util.*;

/***
 * Handles parsing the format string.
 * <p>
 * ${param[,[-]width[,max]]}
 *
 * @author Soren, www.tanesha.net
 */
public class ReplacerFormat {

    public static final boolean LEFT = true;
    public static final boolean RIGHT = false;
    public static final int UNDEF = -1;

    // default start of a replacement token
    public static final String REPLACER_START = "${";

    // default end of a replacement token
    public static final String REPLACER_END = "}";

    /**
     * Create a new ReplacerFormat from a string.
     *
     * @param input the String containing the format
     * @throws FormatterException if the string contains an invalid format for formatting.
     */
    public static ReplacerFormat createFormat(String input) throws FormatterException {
        return createFormat(input, REPLACER_START, REPLACER_END);
    }

    /**
     * Create ReplacerFormat using alternative start/end tokens.
     */
    public static ReplacerFormat createFormat(String input, String start, String end)
        throws FormatterException {

        return new ReplacerFormat(input, start, end);
    }


    private List _items = new LinkedList();
    private String _input;

    private ReplacerFormat(String input, String start, String end) throws FormatterException {

        _input = input;
        parseFormat(start, end);
    }

    public String toString() {
        return "[ReplacerFormat" + _items.toString() + "]";
    }

    private void parseFormat(String start, String end) throws FormatterException {

        try {


            int offset = 0;
            int inputlength = _input.length();

            while (offset < inputlength) {

                int nextd = _input.indexOf(start, offset);

                if (nextd == -1)
                    break;

                int nexte = _input.indexOf(end, nextd);

                // error, ${ without ending }
                if (nexte == -1)
                    throw new FormatterException("Start-tag without end-tag.");

                String foundKey = _input.substring(nextd + start.length(), nexte);
                
                _items.add(new PlainTextElement(_input.substring(offset, nextd)));

                _items.add(new ExpandingElement(foundKey));

                offset = nexte + end.length();
            }

            // add trail
            if (offset < inputlength)
                _items.add(new PlainTextElement(_input.substring(offset, inputlength)));
        }
        catch (Exception e) {
            throw new FormatterException(e.getMessage());
        }

    }


    protected String format(ReplacerEnvironment env) {

        StringBuffer out = new StringBuffer();

        for (Iterator i = _items.iterator(); i.hasNext(); ) {

            Object o = i.next();

            if (o instanceof PlainTextElement) {

                out.append(((PlainTextElement)o).getText());
            }
            else if (o instanceof ExpandingElement) {

                formatExpanding(out, env, (ExpandingElement) o);
            }

        }

        return out.toString();
    }

    private static void formatExpanding(StringBuffer buf,
                                        ReplacerEnvironment env, ExpandingElement elem) {


        Object rep = env.resolve(elem.param());

        // could not be resolved.
        if (rep == null) {
            buf.append(elem.orig());
            return;
        }

        if (rep instanceof String)
            formatString(buf, (String) rep, elem);
        else if (rep instanceof Double)
            formatDouble(buf, (Double) rep, elem);
        else if (rep instanceof StringFormatter)
            formatStringFormatter(buf, (StringFormatter) rep, elem);
        else
            formatString(buf, rep.toString(), elem);
    } 

    private static void formatStringFormatter(StringBuffer buf, StringFormatter f, ExpandingElement elem) {

        buf.append(f.format(elem.align(), elem.width(), elem.max()));
    }

    private static void formatDouble(StringBuffer buf, Double d, ExpandingElement elem) {

        boolean minus = false;

        String t = d.toString();

        // System.out.println("double = " + t);

        if (t.startsWith("-")) {
            minus = true;
            t = t.substring(1);
        }

        // 1234.321E12
        int dPoint = t.indexOf(".");
        int ePoint = t.indexOf("E");

        List num = new LinkedList();
        List dec = new LinkedList();
        List tho = new LinkedList();

        List cur = num;

        byte b[] = t.getBytes();
        for (int j = 0; j < b.length; j++) {

            if (j == dPoint)
                cur = dec;
            else if (j == ePoint)
                cur = tho;
            else
                cur.add(new Character((char) b[j]));
        }

        if (ePoint != -1) {
            // correct for E<10th>
            String sCorrect = "";
            for (Iterator thoi = tho.iterator(); thoi.hasNext(); )
                sCorrect += ((Character) thoi.next()).charValue();

            if (!"".equals(sCorrect)) {

                int correct = Integer.parseInt(sCorrect);

                for (int j = 0; j < correct; j++) {

                    if (dec.size() > 0)
                        num.add(dec.remove(0));
                    else
                        num.add(new Character('0'));

                    // System.out.println("num = " + num + ", dec = " + dec);
                }
            }
        }

        StringBuffer sDec = new StringBuffer();
        for (int j = 0; j < elem.max(); j++)
            if (dec.size() > 0)
                sDec.append(((Character)dec.remove(0)).charValue());
            else
                sDec.append('0');

        StringBuffer sNum = new StringBuffer();

        if (sDec.length() > 0)
            sNum.append(".").append(sDec);

        if (elem.width() == UNDEF) {
            // no width specified

            while (num.size() > 0)
                sNum.insert(0, ((Character)num.remove(num.size() - 1)).charValue());

        } else {
            // width specified
            while (sNum.length() < elem.width()) {

                if (num.size() > 0)
                    sNum.insert(0, ((Character)num.remove(num.size() - 1)).charValue());
                else {
                    if (elem.align() == RIGHT)
                        sNum.insert(0, ' ');
                    else
                        sNum.append(' ');
                }
            }

        }

        buf.append(sNum);

    }

    private static void formatString(StringBuffer buf, String str, ExpandingElement elem) {

        boolean align = elem.align();
        int width = elem.width();
        int max = elem.max();
        int delta = UNDEF;

        if (width != UNDEF && str.length() < width)
            delta = width - str.length();

        if (max != UNDEF && str.length() > max) {
            str = str.substring(0, max);
            delta = UNDEF;
        }


        if (delta != UNDEF && align == RIGHT)
            for (int i = 0; i < delta; i++)
                buf.append(" ");

        buf.append(str);

        if (delta != UNDEF && align == LEFT)
            for (int i = 0; i < delta; i++)
                buf.append(" ");
    }

    private class PlainTextElement {
        private String _text;

        public PlainTextElement(String text) {
            _text = text;
        }
        public String getText() {
            return _text;
        }
    }

    private class ExpandingElement {
        private boolean _align = RIGHT;
        private int _width = UNDEF;
        private int _max = UNDEF;
        private String _param;
        private String _orig;

        public ExpandingElement(String orig) throws Exception {

            _orig = orig;

            int c = orig.indexOf(",");

            if (c == -1) {
                _param = orig;
                return;
            }

            _param = orig.substring(0, c);
            orig = orig.substring(c + 1);

            char first = orig.charAt(0);
            if (first == '-') {
                _align = LEFT;
                orig = orig.substring(1);
            }

            c = orig.indexOf(".");

            if (c == -1) {
                _width = Integer.parseInt(orig);
                return ;
            }

            if (c > 0)
                _width = Integer.parseInt(orig.substring(0, c));
            else
                _width = UNDEF;

            _max = Integer.parseInt(orig.substring(c + 1));

        }

        public String orig() {
            return _orig;
        }
        public String param() {
            return _param;
        }
        public boolean align() {
            return _align;
        }
        public int width() {
            return _width;
        }
        public int max() {
            return _max;
        }
        public String toString() {
            return _orig;
        }
    }

}

/*
 * libreplacer, Java library to support C-sprintf alike text formatting
 * Copyright (C) 2002 Tanesha FTPD Project, www.tanesha.net
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
/*
 * $Id: SimplePrintf.java,v 1.5 2002/12/12 13:06:48 flower Exp $
 */
package org.tanesha.replacer;

/**
 * A C-sprintf alike string formatting class.
 * <p>
 * This is the factory for most of the operations.
 *
 * @author Soren, www.tanesha.net
 */
public class SimplePrintf {

    /**
     * The simplest way of getting something formatted.
     *
     * @param inputFormat the string that needs formatted.
     * @param objs the array of Object to use for formatting
     * @return the new formatted string
     * @throws FormatterException if an exception occured while formatting.
     */
    public static String jprintf(String inputFormat, Object [] objs) throws FormatterException {
        ReplacerFormat format = ReplacerFormat.createFormat(inputFormat);

        return jprintf(format, objs);
    }

    public static String jprintf(String inputFormat, ReplacerEnvironment env) throws FormatterException {
        ReplacerFormat format = ReplacerFormat.createFormat(inputFormat);

        return jprintf(format, env);
    }

    /**
     * Apply an array of Object to a replacer format.
     *
     * @param objs the array of Object to use for formatting
     * @param format the replacer format
     * @return the new formatted string
     * @throws FormatterException if an exception occured while formatting.
     */
    public static String jprintf(ReplacerFormat format, Object[] objs) throws FormatterException {

        // create a replacerenvironment 
        ReplacerEnvironment env = new ReplacerEnvironment();
        for (int i = 0; i < objs.length; i++)
            env.add(String.valueOf(i), objs[i]);

        return jprintf(format, env);
    }

    /**
     * Apply a replacerenvironment to a replacer format
     *
     * @param env The environment with variables to use for formatting
     * @param format the replacer format
     * @return the new formatted string
     * @throws FormatterException if an exception occured while formatting.
     */
    public static String jprintf(ReplacerFormat format, ReplacerEnvironment env) throws FormatterException {
        return format.format(env);
    }

}

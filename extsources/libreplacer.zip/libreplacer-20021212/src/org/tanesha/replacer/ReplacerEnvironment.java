/*
 * libreplacer, Java library to support C-sprintf alike text formatting
 * Copyright (C) 2002 Tanesha FTPD Project, www.tanesha.net
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
/*
 * $Id: ReplacerEnvironment.java,v 1.6 2002/12/12 13:06:48 flower Exp $
 */
package org.tanesha.replacer;

import java.util.Map;
import java.util.HashMap;

/**
 * An environment for holding variables for replacement.
 *
 *
 * @author Soren, www.tanesha.net
 */
public class ReplacerEnvironment {

    private Map _macros = new HashMap();
    private ReplacerEnvironment _parent;

    /**
     * Create a new 'root' replacer environement.
     *
     */
    public ReplacerEnvironment() {
        this(null);
    }

    /**
     * Create a new local replacer environment with a parent.
     *
     * @param parent the parent replacer environment
     */
    public ReplacerEnvironment(ReplacerEnvironment parent) {
        _parent = parent;
    }

    protected Object resolve(String key) {
        if (_macros.containsKey(key))
            return _macros.get(key);
        else if (_parent != null)
            return _parent.resolve(key);

        return null;
    }

    /**
     * Adds a new object to the replacer environment
     *
     * @param key The name of the new object
     * @param value the value of the new replacer item
     * @return this for chaining add(.., ..)
     */
    public ReplacerEnvironment add(String key, Object value) {
        _macros.put(key, value);

        return this;
    }

    /**
     * Create a new ReplacerEnvironment which has two parent environments.
     *
     * @param e1 The first replacer environment, this will be searched first.
     * @param e2 The second replacer environment, this will be searched last.
     */
    public static ReplacerEnvironment chain(ReplacerEnvironment e1, ReplacerEnvironment e2) {
        return new ChainedReplacerEnvironment(e1, e2);
    }

    private static class ChainedReplacerEnvironment extends ReplacerEnvironment {

        ReplacerEnvironment _e2;

        public ChainedReplacerEnvironment(ReplacerEnvironment e1, ReplacerEnvironment e2) {
            super(e1);

            _e2 = e2;
        }

        public Object resolve(String key) {
            Object t = super.resolve(key);
            if (t == null) {
                t = _e2.resolve(key);
            }

            return t;
        }
    }

}

package com.googlecode.mp4parser.authoring.tracks.webvtt.sampleboxes;

public class CueSettingsBox extends AbstractCueBox {
    public CueSettingsBox() {
        super("sttg");
    }
}

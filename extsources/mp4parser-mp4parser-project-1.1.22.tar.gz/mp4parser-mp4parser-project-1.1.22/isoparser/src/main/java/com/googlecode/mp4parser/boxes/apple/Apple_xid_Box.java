package com.googlecode.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/15/13.
 */
public class Apple_xid_Box extends Utf8AppleDataBox {
    public Apple_xid_Box() {
        super("xid ");
    }
}

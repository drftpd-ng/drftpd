package com.mp4parser.streaming;

/**
 * Marker interface for any kind of extension to a track.
 */
public interface TrackExtension {
}

package com.googlecode.mp4parser.authoring.tracks.webvtt.sampleboxes;

public class VTTAdditionalTextBox extends AbstractCueBox {
    public VTTAdditionalTextBox() {
        super("vtta");
    }
}

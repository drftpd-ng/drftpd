package com.googlecode.mp4parser.authoring.tracks.webvtt.sampleboxes;

public class CueIDBox extends AbstractCueBox {
    public CueIDBox() {
        super("iden");
    }
}

package com.googlecode.mp4parser.authoring.tracks.webvtt.sampleboxes;

public class CuePayloadBox extends AbstractCueBox {
    public CuePayloadBox() {
        super("payl");
    }
}

package com.googlecode.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/15/13.
 */
public class Apple_flvr_Box extends Utf8AppleDataBox {
    public Apple_flvr_Box() {
        super("flvr");
    }
}

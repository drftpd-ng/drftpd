package com.googlecode.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/15/13.
 */
public class AppleArtistBox extends Utf8AppleDataBox {
    public AppleArtistBox() {
        super("©ART");
    }
}

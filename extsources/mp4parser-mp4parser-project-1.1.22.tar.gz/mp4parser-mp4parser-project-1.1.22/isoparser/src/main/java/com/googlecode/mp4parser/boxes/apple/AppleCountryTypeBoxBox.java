package com.googlecode.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/22/13.
 */
public class AppleCountryTypeBoxBox extends AppleVariableSignedIntegerBox {
    public AppleCountryTypeBoxBox() {
        super("sfID");
    }
}

package com.googlecode.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/22/13.
 */
public class AppleGaplessPlaybackBox extends AppleVariableSignedIntegerBox {
    public AppleGaplessPlaybackBox() {
        super("pgap");
    }
}

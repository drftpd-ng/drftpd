package com.googlecode.mp4parser.authoring.tracks.webvtt.sampleboxes;

public class CueTimeBox extends AbstractCueBox {
    public CueTimeBox() {
        super("ctim");
    }
}

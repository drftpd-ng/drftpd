package com.googlecode.mp4parser.authoring.tracks.webvtt.sampleboxes;

public class CueSourceIDBox extends AbstractCueBox {
    public CueSourceIDBox() {
        super("vsid");
    }
}

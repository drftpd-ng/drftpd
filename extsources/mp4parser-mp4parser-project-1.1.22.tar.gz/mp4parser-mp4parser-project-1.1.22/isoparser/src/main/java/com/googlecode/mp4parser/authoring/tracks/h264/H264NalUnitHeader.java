package com.googlecode.mp4parser.authoring.tracks.h264;


public class H264NalUnitHeader {
    public int nal_ref_idc;
    public int nal_unit_type;
}

package com.mp4parser.streaming.extensions;

import com.mp4parser.streaming.TrackExtension;

/**
 * Purely a marker to signal that the track's samples will have {@link }
 */
public class CompositionTimeTrackExtension implements TrackExtension {
}

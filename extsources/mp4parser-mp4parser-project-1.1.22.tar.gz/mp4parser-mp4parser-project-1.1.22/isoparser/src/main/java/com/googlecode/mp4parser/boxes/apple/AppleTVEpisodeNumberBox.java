package com.googlecode.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/15/13.
 */
public class AppleTVEpisodeNumberBox extends Utf8AppleDataBox {
    public AppleTVEpisodeNumberBox() {
        super("tven");
    }
}

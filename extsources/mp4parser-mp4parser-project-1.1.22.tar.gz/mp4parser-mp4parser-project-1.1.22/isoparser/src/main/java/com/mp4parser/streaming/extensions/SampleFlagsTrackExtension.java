package com.mp4parser.streaming.extensions;

import com.mp4parser.streaming.TrackExtension;

/**
 * Created by sannies on 22.05.2015.
 */
public class SampleFlagsTrackExtension implements TrackExtension {
}

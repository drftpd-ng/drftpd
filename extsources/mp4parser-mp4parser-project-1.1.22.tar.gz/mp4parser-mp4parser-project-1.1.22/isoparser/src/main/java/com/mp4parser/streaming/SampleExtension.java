package com.mp4parser.streaming;

/**
 * Marker interface for any kind of extension to a sample.
 */
public interface SampleExtension {
}

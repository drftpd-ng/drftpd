package org.junit.tests.experimental.theories.extendingwithstubs;

public interface Correspondent {

	String getAnswer(String question, String... bucket);

}

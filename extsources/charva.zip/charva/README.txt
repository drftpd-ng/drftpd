This is version 1.1.4 of Charva, released on 2006/9/11.
=======================================================

For instructions on building and installing this software, look at the
file "docs/Download.html".

Enjoy!
Rob Pitman

package com.cedarsoftware.util.io

class CustomDataClass
{

	private String test;

	public void setTest(String test) {
		this.test = test;
	}

	public String getTest() {
		return test;
	}
}

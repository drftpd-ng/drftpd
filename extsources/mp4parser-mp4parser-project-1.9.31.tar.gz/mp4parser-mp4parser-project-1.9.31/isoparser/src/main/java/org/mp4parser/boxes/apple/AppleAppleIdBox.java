package org.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/15/13.
 */
public class AppleAppleIdBox extends Utf8AppleDataBox {
    public AppleAppleIdBox() {
        super("apID");
    }
}

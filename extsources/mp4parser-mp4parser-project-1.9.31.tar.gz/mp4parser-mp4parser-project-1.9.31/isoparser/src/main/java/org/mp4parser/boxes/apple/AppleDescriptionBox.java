package org.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/15/13.
 */
public class AppleDescriptionBox extends Utf8AppleDataBox {
    public AppleDescriptionBox() {
        super("desc");
    }
}

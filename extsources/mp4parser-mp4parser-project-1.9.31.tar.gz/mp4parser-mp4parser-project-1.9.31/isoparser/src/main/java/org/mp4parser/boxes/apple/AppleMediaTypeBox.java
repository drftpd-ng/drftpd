package org.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/22/13.
 */
public class AppleMediaTypeBox extends AppleVariableSignedIntegerBox {
    public AppleMediaTypeBox() {
        super("stik");
    }
}

package org.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/22/13.
 */
public class Apple_geIDBox extends AppleVariableSignedIntegerBox {
    public Apple_geIDBox() {
        super("geID");
    }
}

package org.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/15/13.
 */
public class AppleAlbumBox extends Utf8AppleDataBox {
    public AppleAlbumBox() {
        super("©alb");
    }
}

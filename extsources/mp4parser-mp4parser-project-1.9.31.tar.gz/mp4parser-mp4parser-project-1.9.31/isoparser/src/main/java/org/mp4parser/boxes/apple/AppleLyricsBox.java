package org.mp4parser.boxes.apple;

/**
 * Created by Tobias Bley / UltraMixer on 04/25/2014.
 */
public class AppleLyricsBox extends Utf8AppleDataBox {
    public AppleLyricsBox() {
        super("©lyr");
    }
}

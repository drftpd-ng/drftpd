package org.mp4parser.boxes.apple;

/**
 * Created by Tobias Bley / UltraMixer on 04/25/2014.
 */
public class AppleCommentBox extends Utf8AppleDataBox {
    public AppleCommentBox() {
        super("©cmt");
    }
}

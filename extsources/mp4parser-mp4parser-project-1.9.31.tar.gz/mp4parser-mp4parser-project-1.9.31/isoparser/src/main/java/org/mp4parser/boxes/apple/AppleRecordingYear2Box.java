package org.mp4parser.boxes.apple;

/**
 * Created by Tobias Bley, / UltraMixer
 */
public class AppleRecordingYear2Box extends Utf8AppleDataBox {

    public AppleRecordingYear2Box() {
        super("©day");
    }

}

package org.mp4parser.boxes.apple;

/**
 * Created by sannies on 10/15/13.
 */
public class AppleCopyrightBox extends Utf8AppleDataBox {
    public AppleCopyrightBox() {
        super("cprt");
    }
}

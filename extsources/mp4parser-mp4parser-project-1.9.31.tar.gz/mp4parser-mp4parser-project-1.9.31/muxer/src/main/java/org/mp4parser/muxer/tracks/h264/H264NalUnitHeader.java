package org.mp4parser.muxer.tracks.h264;


public class H264NalUnitHeader {
    public int nal_ref_idc;
    public int nal_unit_type;
}
